extends RefCounted
# data.gd - all static game data (tiers, weapons, ships, aircraft, abilities, visual styles)
# plus a few pure geometry helpers.  No game logic lives here, so you can add ships and
# weapons just by editing this file.
#
# HOW TO ADD A SHIP: copy one of the _s(...) lines in _build() and change the numbers.
# HOW TO ADD A WEAPON: add an entry to WEAPONS and use its id in a ship's g("id", ...) group.
#
# Mount coordinates are fractions: x = fraction of hull LENGTH (+ = bow), y = fraction of
# hull WIDTH (+ = starboard).  Angles are in degrees (0 = straight ahead, 90 = starboard).

const TIER_NEED := [0, 100, 280, 600, 1100, 1800, 2800, 4200]
const TIER_ZOOM := [1.0, 0.92, 0.84, 0.76, 0.68, 0.60, 0.54, 0.48]
const ROMAN := ["I", "II", "III", "IV", "V", "VI", "VII", "VIII"]
const MAX_TIER := 8
const KIND := {"bullet": 0, "shell": 1, "torp": 2, "missile": 3, "rocket": 4, "mine": 5, "bomb": 6}

# ---------------------------------------------------------------------------------------
# WEAPONS
#  n=name  vis=how the mount is drawn  pk=projectile kind  dmg=damage per projectile
#  spd=projectile speed  rng=range (px)  rl=reload PER BARREL (s)  gap=min time between
#  shots of this weapon (s)  spr=random spread (rad)  trav=mount traverse speed (rad/s)
#  sal=projectiles per shot  mode=0 fly to aim point, 1 follow cursor, 2 seeker homing
#  turn=projectile turn rate  seek=seeker range  spl=splash radius  bw/bl=barrel width/length
#  aa=can hit aircraft  pd=point defence (auto-shoots incoming missiles)  pick=choose the
#  mount closest to the aim direction instead of firing in sequence  ic=HUD icon
# ---------------------------------------------------------------------------------------
const WEAPONS := {
	"mg": {"n": "12.7mm Machine Gun", "vis": "gun", "pk": "bullet", "dmg": 1.8, "spd": 720.0, "rng": 430.0, "rl": 0.2, "gap": 0.05, "spr": 0.07, "trav": 9.0, "bw": 0.8, "bl": 5.0, "snd": "mg", "aa": true, "ic": "bullet", "ar": 12.0},
	"ac20": {"n": "20mm Autocannon", "vis": "gun", "pk": "bullet", "dmg": 2.6, "spd": 700.0, "rng": 520.0, "rl": 0.4, "gap": 0.08, "spr": 0.05, "trav": 7.0, "bw": 1.0, "bl": 6.0, "snd": "ac", "aa": true, "ic": "bullet", "ar": 14.0},
	"ac40": {"n": "40mm Bofors", "vis": "gun", "pk": "bullet", "dmg": 3.6, "spd": 640.0, "rng": 620.0, "rl": 0.75, "gap": 0.12, "spr": 0.045, "trav": 5.0, "bw": 1.0, "bl": 8.0, "snd": "ac", "aa": true, "ic": "shell_s", "ar": 18.0},
	"g76": {"n": "76mm Dual-Purpose Gun", "vis": "gun", "pk": "shell", "dmg": 12.0, "spd": 650.0, "rng": 740.0, "rl": 1.0, "gap": 0.28, "spr": 0.03, "trav": 4.5, "bw": 1.2, "bl": 11.0, "spl": 10.0, "snd": "gun_s", "aa": true, "ic": "shell_s", "ar": 28.0},
	"g76r": {"n": "76mm Super Rapid", "vis": "gun", "pk": "shell", "dmg": 10.0, "spd": 660.0, "rng": 760.0, "rl": 0.6, "gap": 0.2, "spr": 0.03, "trav": 5.5, "bw": 1.2, "bl": 11.0, "spl": 9.0, "snd": "gun_s", "aa": true, "ic": "shell_s", "ar": 28.0, "mod": true},
	"g100": {"n": "100mm Gun", "vis": "gun", "pk": "shell", "dmg": 16.0, "spd": 640.0, "rng": 800.0, "rl": 1.5, "gap": 0.35, "spr": 0.03, "trav": 3.8, "bw": 1.4, "bl": 13.0, "spl": 13.0, "snd": "gun_s", "aa": true, "ic": "shell_s", "ar": 30.0},
	"g127": {"n": "127mm Gun", "vis": "gun", "pk": "shell", "dmg": 21.0, "spd": 630.0, "rng": 870.0, "rl": 1.9, "gap": 0.4, "spr": 0.028, "trav": 3.5, "bw": 1.6, "bl": 15.0, "spl": 17.0, "snd": "gun_m", "ic": "shell_m", "aa": true, "ar": 32.0},
	"g127m": {"n": "127mm Mk 45 Automatic", "vis": "gun", "pk": "shell", "dmg": 19.0, "spd": 650.0, "rng": 900.0, "rl": 1.2, "gap": 0.3, "spr": 0.025, "trav": 4.5, "bw": 1.6, "bl": 15.0, "spl": 16.0, "snd": "gun_m", "ic": "shell_m", "aa": true, "ar": 32.0, "mod": true},
	"g155": {"n": "155mm Advanced Gun", "vis": "gun", "pk": "shell", "dmg": 38.0, "spd": 640.0, "rng": 1100.0, "rl": 2.4, "gap": 0.5, "spr": 0.02, "trav": 3.2, "bw": 2.0, "bl": 19.0, "spl": 26.0, "snd": "gun_m", "ic": "shell_m", "mod": true},
	"g152": {"n": "152mm Gun", "vis": "gun", "pk": "shell", "dmg": 28.0, "spd": 610.0, "rng": 950.0, "rl": 2.7, "gap": 0.45, "spr": 0.028, "trav": 2.8, "bw": 1.9, "bl": 18.0, "spl": 22.0, "snd": "gun_m", "ic": "shell_m"},
	"g203": {"n": "203mm Gun", "vis": "gun", "pk": "shell", "dmg": 44.0, "spd": 600.0, "rng": 1030.0, "rl": 3.5, "gap": 0.5, "spr": 0.026, "trav": 2.3, "bw": 2.2, "bl": 21.0, "spl": 30.0, "snd": "gun_l", "ic": "shell_l"},
	"g305": {"n": "305mm Gun", "vis": "gun", "pk": "shell", "dmg": 72.0, "spd": 590.0, "rng": 1120.0, "rl": 4.3, "gap": 0.55, "spr": 0.025, "trav": 1.8, "bw": 2.5, "bl": 25.0, "spl": 38.0, "snd": "gun_l", "ic": "shell_l"},
	"g356": {"n": "356mm Gun", "vis": "gun", "pk": "shell", "dmg": 90.0, "spd": 585.0, "rng": 1180.0, "rl": 4.8, "gap": 0.6, "spr": 0.024, "trav": 1.6, "bw": 2.7, "bl": 27.0, "spl": 42.0, "snd": "gun_xl", "ic": "shell_l"},
	"g381": {"n": "381mm Gun", "vis": "gun", "pk": "shell", "dmg": 110.0, "spd": 580.0, "rng": 1240.0, "rl": 5.2, "gap": 0.65, "spr": 0.024, "trav": 1.5, "bw": 2.8, "bl": 29.0, "spl": 46.0, "snd": "gun_xl", "ic": "shell_l"},
	"g406": {"n": "406mm Gun", "vis": "gun", "pk": "shell", "dmg": 125.0, "spd": 580.0, "rng": 1300.0, "rl": 5.6, "gap": 0.7, "spr": 0.022, "trav": 1.4, "bw": 3.0, "bl": 31.0, "spl": 50.0, "snd": "gun_xl", "ic": "shell_l"},
	"g460": {"n": "460mm Gun", "vis": "gun", "pk": "shell", "dmg": 150.0, "spd": 575.0, "rng": 1380.0, "rl": 6.2, "gap": 0.75, "spr": 0.022, "trav": 1.2, "bw": 3.2, "bl": 34.0, "spl": 56.0, "snd": "gun_xl", "ic": "shell_l"},
	"ciws": {"n": "CIWS Gatling", "vis": "ciws", "pk": "bullet", "dmg": 0.8, "spd": 800.0, "rng": 400.0, "rl": 0.45, "gap": 0.03, "spr": 0.05, "trav": 9.0, "bw": 1.0, "bl": 6.0, "snd": "ciws", "aa": true, "pd": true, "ic": "bullet", "ar": 15.0},
	"torp": {"n": "533mm Torpedo", "vis": "tubes", "pk": "torp", "dmg": 55.0, "spd": 250.0, "rng": 900.0, "rl": 9.0, "gap": 0.6, "spr": 0.02, "trav": 1.4, "mode": 0, "turn": 1.1, "spl": 24.0, "pick": true, "snd": "torp", "ic": "torp", "tl": 12.0},
	"torp_l": {"n": "Lightweight Homing Torpedo", "vis": "tubes", "pk": "torp", "dmg": 38.0, "spd": 290.0, "rng": 650.0, "rl": 6.0, "gap": 0.5, "spr": 0.02, "trav": 1.6, "mode": 2, "turn": 2.2, "seek": 420.0, "spl": 18.0, "pick": true, "snd": "torp", "ic": "torp", "tl": 9.0},
	"torp_h": {"n": "Long Lance Torpedo", "vis": "tubes", "pk": "torp", "dmg": 150.0, "spd": 330.0, "rng": 1400.0, "rl": 14.0, "gap": 0.8, "spr": 0.015, "trav": 1.2, "mode": 0, "turn": 0.9, "spl": 36.0, "pick": true, "snd": "torp", "ic": "torp", "tl": 16.0, "seek": 0.0},
	"torp_w": {"n": "Wire-Guided Torpedo", "vis": "tubes", "pk": "torp", "dmg": 95.0, "spd": 300.0, "rng": 1200.0, "rl": 11.0, "gap": 0.8, "spr": 0.015, "trav": 1.4, "mode": 2, "turn": 2.0, "spl": 30.0, "pick": true, "snd": "torp", "ic": "torp", "tl": 14.0, "seek": 520.0},
	"mine": {"n": "Mine / Depth Charge Rack", "vis": "mine", "pk": "mine", "dmg": 80.0, "spd": 40.0, "rng": 60.0, "rl": 8.0, "gap": 1.2, "spr": 0.3, "trav": 1.0, "spl": 55.0, "snd": "mine", "ic": "mine"},
	"rocket": {"n": "Rocket Barrage", "vis": "rack", "pk": "rocket", "dmg": 6.5, "sal": 8, "spd": 460.0, "rng": 720.0, "rl": 7.0, "gap": 0.8, "spr": 0.16, "trav": 2.0, "mode": 0, "turn": 0.6, "spl": 15.0, "snd": "rocket", "ic": "rocket", "mt": 5},
	"rocket_h": {"n": "Unguided Missile Salvo", "vis": "rack", "pk": "rocket", "dmg": 22.0, "sal": 2, "spd": 540.0, "rng": 1100.0, "rl": 11.0, "gap": 1.0, "spr": 0.05, "trav": 1.6, "mode": 0, "turn": 0.0, "spl": 22.0, "snd": "rocket", "ic": "rocket_h", "mt": 6},
	"ssm_s": {"n": "Light Anti-Ship Missile", "vis": "can", "pk": "missile", "dmg": 36.0, "spd": 380.0, "rng": 1500.0, "rl": 12.0, "gap": 1.1, "spr": 0.02, "trav": 1.5, "mode": 2, "turn": 2.6, "seek": 700.0, "spl": 18.0, "snd": "missile", "ic": "missile_s", "mt": 1},
	"ssm_l": {"n": "Sea-Skimmer Anti-Ship Missile", "vis": "can", "pk": "missile", "dmg": 70.0, "spd": 420.0, "rng": 2300.0, "rl": 16.0, "gap": 1.5, "spr": 0.02, "trav": 1.5, "mode": 2, "turn": 2.3, "seek": 900.0, "spl": 24.0, "snd": "missile", "ic": "missile", "mt": 2},
	"ssm_h": {"n": "Heavy Supersonic Missile", "vis": "can", "pk": "missile", "dmg": 150.0, "spd": 520.0, "rng": 3200.0, "rl": 24.0, "gap": 2.0, "spr": 0.02, "trav": 1.5, "mode": 2, "turn": 1.7, "seek": 1200.0, "spl": 42.0, "snd": "missile", "ic": "missile_h", "mt": 3},
	"cruise": {"n": "Long-Range Cruise Missile", "vis": "vls", "pk": "missile", "dmg": 90.0, "spd": 430.0, "rng": 4200.0, "rl": 20.0, "gap": 1.5, "spr": 0.0, "trav": 1.0, "mode": 2, "turn": 3.0, "spl": 32.0, "snd": "missile", "ic": "cruise", "seek": 1500.0, "mt": 4},
	"a_mg": {"n": "Door / Chain Gun", "vis": "gun", "pk": "bullet", "dmg": 2.4, "spd": 700.0, "rng": 480.0, "rl": 0.16, "gap": 0.06, "spr": 0.06, "trav": 9.0, "bw": 0.8, "bl": 5.0, "snd": "mg", "ic": "bullet"},
	"a_rocket": {"n": "Rocket Pod", "vis": "rack", "pk": "rocket", "dmg": 7.0, "sal": 6, "spd": 520.0, "rng": 700.0, "rl": 8.0, "gap": 0.9, "spr": 0.1, "trav": 1.0, "mode": 0, "turn": 0.0, "spl": 14.0, "snd": "rocket", "ic": "rocket", "mt": 5},
	"a_torp": {"n": "Air-Dropped Torpedo", "vis": "tubes", "pk": "torp", "dmg": 70.0, "spd": 260.0, "rng": 800.0, "rl": 14.0, "gap": 1.0, "spr": 0.0, "trav": 1.0, "mode": 2, "turn": 1.5, "seek": 260.0, "spl": 26.0, "snd": "torp", "ic": "torp", "tl": 9.0},
	"bomb_s": {"n": "Light Bombs", "vis": "rack", "pk": "bomb", "dmg": 28.0, "spd": 0.0, "rng": 0.0, "rl": 7.0, "gap": 0.5, "spr": 0.0, "trav": 1.0, "spl": 34.0, "snd": "bomb", "ic": "bomb"},
	"bomb_l": {"n": "Heavy Bombs", "vis": "rack", "pk": "bomb", "dmg": 110.0, "spd": 0.0, "rng": 0.0, "rl": 12.0, "gap": 1.0, "spr": 0.0, "trav": 1.0, "spl": 52.0, "snd": "bomb", "ic": "bomb"},
	"mark": {"n": "Target Designator", "vis": "rack", "pk": "bullet", "dmg": 0.0, "spd": 0.0, "rng": 700.0, "rl": 6.0, "gap": 0.2, "spr": 0.0, "trav": 1.0, "special": "mark", "snd": "ping", "ic": "mark"},
}

# ---------------------------------------------------------------------------------------
# AIRCRAFT  (launched from some ships, press V to take control)
#  vis = detection radius around the aircraft, leash = max distance from its ship,
#  cd = rebuild time after being shot down, w = [[weapon id, barrels], ...]
# ---------------------------------------------------------------------------------------
const AIR := {
	"uav": {"n": "Recon Drone", "kind": "plane", "hp": 14.0, "spd": 250.0, "turn": 3.2, "vis": 1500.0, "leash": 2000.0, "cd": 18.0, "cam": 0.8, "size": 0.7, "col": Color(0.82, 0.84, 0.86), "w": [["mark", 1]], "desc": "Long-range recon. Marks enemies (+25% damage taken)."},
	"heli_scout": {"n": "Scout Helicopter", "kind": "heli", "hp": 28.0, "spd": 215.0, "turn": 2.8, "vis": 1250.0, "leash": 1500.0, "cd": 22.0, "cam": 0.85, "size": 1.0, "col": Color(0.70, 0.74, 0.78), "w": [["mark", 1]], "desc": "Hovering spotter. Marks enemies for your guns."},
	"heli_asw": {"n": "ASW Helicopter", "kind": "heli", "hp": 36.0, "spd": 190.0, "turn": 2.6, "vis": 900.0, "leash": 1400.0, "cd": 24.0, "cam": 0.85, "size": 1.1, "col": Color(0.36, 0.40, 0.44), "w": [["a_torp", 2], ["a_mg", 1]], "desc": "Drops homing torpedoes and has a door gun."},
	"heli_attack": {"n": "Attack Helicopter", "kind": "heli", "hp": 48.0, "spd": 205.0, "turn": 2.6, "vis": 800.0, "leash": 1500.0, "cd": 26.0, "cam": 0.85, "size": 1.2, "col": Color(0.22, 0.26, 0.22), "turret": true, "w": [["a_mg", 2], ["a_rocket", 1]], "desc": "Chain gun that follows the cursor, plus rocket pods."},
	"floatplane": {"n": "Spotter Floatplane", "kind": "plane", "hp": 20.0, "spd": 270.0, "turn": 2.0, "vis": 1400.0, "leash": 2400.0, "cd": 22.0, "cam": 0.75, "size": 1.0, "col": Color(0.60, 0.64, 0.58), "w": [["mark", 1], ["bomb_s", 2]], "desc": "Fast scout. Marks targets and drops light bombs."},
	"carrier_bomber": {"n": "Dive Bomber", "kind": "plane", "hp": 60.0, "spd": 310.0, "turn": 1.7, "vis": 1000.0, "leash": 2600.0, "cd": 16.0, "cam": 0.72, "size": 1.5, "col": Color(0.30, 0.34, 0.42), "w": [["bomb_l", 2], ["a_mg", 2]], "desc": "Heavy bombs and forward machine guns."},
}

const ABILITIES := {
	"boost": {"n": "Flank Speed", "dur": 4.0, "cd": 22.0, "desc": "+45% speed"},
	"repair": {"n": "Damage Control", "dur": 6.0, "cd": 35.0, "desc": "Restores 30% hull"},
	"smoke": {"n": "Smoke Screen", "dur": 9.0, "cd": 30.0, "desc": "Enemies spot you from far less distance"},
	"radar": {"n": "Radar Sweep", "dur": 6.0, "cd": 28.0, "desc": "Reveals every ship on the map"},
	"barrage": {"n": "Barrage", "dur": 6.0, "cd": 38.0, "desc": "Weapons reload twice as fast"},
	"chaff": {"n": "Countermeasures", "dur": 0.5, "cd": 24.0, "desc": "Nearby missiles and torpedoes lose lock"},
}

const PAL := {
	"us": {"hull": Color(0.40, 0.45, 0.50), "deck": Color(0.52, 0.49, 0.42), "sup": Color(0.62, 0.66, 0.70)},
	"de": {"hull": Color(0.37, 0.40, 0.43), "deck": Color(0.44, 0.41, 0.37), "sup": Color(0.56, 0.59, 0.61)},
	"jp": {"hull": Color(0.33, 0.37, 0.40), "deck": Color(0.49, 0.41, 0.32), "sup": Color(0.50, 0.53, 0.56)},
	"ru": {"hull": Color(0.47, 0.52, 0.56), "deck": Color(0.38, 0.41, 0.43), "sup": Color(0.67, 0.70, 0.72)},
	"mod": {"hull": Color(0.48, 0.53, 0.58), "deck": Color(0.42, 0.45, 0.48), "sup": Color(0.72, 0.75, 0.78)},
	"pt": {"hull": Color(0.36, 0.42, 0.38), "deck": Color(0.50, 0.43, 0.30), "sup": Color(0.58, 0.61, 0.57)},
	"cv": {"hull": Color(0.40, 0.44, 0.48), "deck": Color(0.26, 0.28, 0.30), "sup": Color(0.58, 0.61, 0.65)},
}

# bow = where the bow taper starts (0..1 along the hull), bp = bow fullness, st = stern width
# sup = [x, length, width] superstructure blocks, fun = funnel x positions, mast = mast x
const STYLES := {
	"pt": {"bow": 0.55, "bp": 1.6, "st": 0.72, "pal": "pt", "sup": [[0.02, 0.30, 0.50]], "fun": [], "mast": [0.02]},
	"boat": {"bow": 0.62, "bp": 1.7, "st": 0.75, "pal": "pt", "sup": [[0.12, 0.26, 0.50], [-0.12, 0.18, 0.40]], "fun": [], "mast": [0.12]},
	"ww2s": {"bow": 0.72, "bp": 1.7, "st": 0.80, "pal": "us", "sup": [[0.08, 0.20, 0.55], [-0.14, 0.12, 0.40]], "fun": [-0.08], "mast": [0.08, -0.24]},
	"ww2m": {"bow": 0.74, "bp": 1.7, "st": 0.82, "pal": "us", "sup": [[0.12, 0.14, 0.55], [-0.06, 0.10, 0.45]], "fun": [0.0, -0.14], "mast": [0.12, -0.10]},
	"ww2l": {"bow": 0.78, "bp": 1.8, "st": 0.86, "pal": "us", "sup": [[0.10, 0.10, 0.50], [0.03, 0.07, 0.34], [-0.07, 0.13, 0.55]], "fun": [-0.04, -0.15], "mast": [0.10, -0.26]},
	"jpm": {"bow": 0.74, "bp": 1.7, "st": 0.80, "pal": "jp", "sup": [[0.12, 0.12, 0.55], [-0.04, 0.10, 0.45]], "fun": [0.02, -0.10, -0.18], "mast": [0.12]},
	"jpl": {"bow": 0.78, "bp": 1.8, "st": 0.84, "pal": "jp", "sup": [[0.10, 0.09, 0.55], [0.10, 0.05, 0.34], [-0.02, 0.12, 0.50]], "fun": [-0.08, -0.17], "mast": [0.10]},
	"mods": {"bow": 0.74, "bp": 1.8, "st": 0.88, "pal": "mod", "sup": [[0.06, 0.40, 0.55]], "fun": [], "mast": [0.10]},
	"modm": {"bow": 0.76, "bp": 1.8, "st": 0.90, "pal": "mod", "sup": [[0.10, 0.18, 0.55], [-0.12, 0.20, 0.55]], "fun": [], "mast": [0.10, -0.12]},
	"modl": {"bow": 0.78, "bp": 1.9, "st": 0.90, "pal": "mod", "sup": [[0.10, 0.16, 0.55], [-0.10, 0.20, 0.55]], "fun": [], "mast": [0.10, -0.10]},
	"rum": {"bow": 0.74, "bp": 1.8, "st": 0.88, "pal": "ru", "sup": [[0.12, 0.20, 0.55], [-0.12, 0.16, 0.50]], "fun": [-0.02, -0.16], "mast": [0.12]},
	"rul": {"bow": 0.78, "bp": 1.9, "st": 0.90, "pal": "ru", "sup": [[0.14, 0.16, 0.55], [-0.10, 0.18, 0.55]], "fun": [-0.04, -0.14], "mast": [0.14, -0.10]},
	"cv": {"bow": 0.82, "bp": 1.9, "st": 0.88, "pal": "cv", "sup": [], "fun": [], "mast": []},
	"ars": {"bow": 0.78, "bp": 2.0, "st": 0.92, "pal": "mod", "sup": [[-0.30, 0.16, 0.55], [0.0, 0.08, 0.40]], "fun": [], "mast": [-0.30, 0.0]},
}

static var _ships: Array = []
static var _by_id: Dictionary = {}

static func ships() -> Array:
	if _ships.is_empty():
		_ships = _build()
		for s in _ships:
			_by_id[str(s["id"])] = s
	return _ships

static func by_id(id: String) -> Dictionary:
	ships()
	return _by_id.get(id, {})

static func of_tier(t: int) -> Array:
	var out: Array = []
	for s in ships():
		if int(s["tier"]) == t:
			out.append(s)
	return out

static func tier_progress(score: float, tier: int) -> float:
	if tier >= MAX_TIER:
		return clampf((score - float(TIER_NEED[MAX_TIER - 1])) / 1500.0, 0.0, 1.0)
	var a := float(TIER_NEED[tier - 1])
	var b := float(TIER_NEED[tier])
	return clampf((score - a) / (b - a), 0.0, 1.0)

# ---- helpers used when building the ship table ----
static func g(w: String, pts: Array, b: int = 1, dir: float = 0.0, arc: float = 180.0) -> Dictionary:
	var ms: Array = []
	for e in pts:
		var m := {"x": float(e[0]), "y": float(e[1]), "b": b, "dir": deg_to_rad(dir), "arc": deg_to_rad(arc)}
		if e.size() > 2:
			m["dir"] = deg_to_rad(float(e[2]))
		if e.size() > 3:
			m["arc"] = deg_to_rad(float(e[3]))
		ms.append(m)
	return {"w": w, "m": ms}

static func _s(id: String, nm: String, tier: int, cls: String, style: String, L: float, W: float, hp: float, spd: float, turn: float, det: float, rlm: float, abil: Array, air: String, weapons: Array, ex: Dictionary = {}) -> Dictionary:
	var d := {"id": id, "name": nm, "tier": tier, "cls": cls, "style": style, "len": L, "wid": W, "hp": hp, "spd": spd, "turn": turn, "det": det, "rlm": rlm, "abil": abil, "air": air, "weapons": weapons, "cam": float(TIER_ZOOM[tier - 1]), "pal": "", "desc": "", "stealth": clampf(0.5 + L / 500.0, 0.6, 1.0)}
	for k in ex.keys():
		d[k] = ex[k]
	# reload speed depends on tier (bigger ships are slower) and era (modern autoloaders are faster)
	var r := rlm * (0.8 + 0.04 * float(tier))
	if style in ["mods", "modm", "modl", "rum", "rul", "ars", "cv"]:
		r *= 0.92
	d["rlm"] = r
	if ex.has("cz"):
		d["cam"] = float(TIER_ZOOM[tier - 1]) * float(ex["cz"])
	return d

static func _build() -> Array:
	var a: Array = []
	# ================= TIER I =================
	a.append(_s("pt_boat", "Elco PT Boat", 1, "Motor Torpedo Boat", "pt", 30.0, 7.5, 70.0, 225.0, 3.2, 520.0, 1.0, ["boost"], "",
		[g("mg", [[0.14, 0.0], [-0.30, 0.0]], 2), g("torp", [[-0.04, 0.34, 90, 60], [-0.04, -0.34, -90, 60]], 1)],
		{"desc": "Fast and fragile. Hit and run with torpedoes."}))
	a.append(_s("fac", "Fast Attack Craft", 1, "Torpedo Boat", "pt", 34.0, 7.5, 75.0, 205.0, 2.8, 560.0, 1.0, ["boost"], "",
		[g("ac40", [[0.28, 0.0]], 1), g("mg", [[-0.30, 0.0]], 2), g("torp", [[-0.04, 0.32, 90, 60], [-0.04, -0.32, -90, 60]], 1)],
		{"desc": "Autocannon, machine guns and torpedoes."}))
	a.append(_s("gunboat", "Patrol Gunboat", 1, "Gunboat", "boat", 32.0, 8.5, 95.0, 175.0, 2.6, 500.0, 1.0, ["repair"], "",
		[g("ac20", [[0.28, 0.0]], 1), g("mg", [[-0.20, 0.0]], 2), g("mine", [[-0.5, 0.0, 180, 10]], 4)],
		{"desc": "Sturdy hull, drops mines behind it."}))
	# ================= TIER II =================
	a.append(_s("flower", "Flower-class Corvette", 2, "Escort Corvette", "ww2s", 50.0, 8.5, 150.0, 150.0, 2.2, 600.0, 1.0, ["repair"], "",
		[g("g100", [[0.30, 0.0]], 1), g("ac40", [[-0.30, 0.0]], 2), g("mine", [[-0.5, 0.0, 180, 10]], 6)],
		{"desc": "Cheap WWII escort with a 100mm gun and depth charges."}))
	a.append(_s("corvette_mod", "Modern Corvette", 2, "Corvette", "mods", 58.0, 9.0, 165.0, 165.0, 2.4, 700.0, 1.0, ["chaff"], "",
		[g("g76r", [[0.28, 0.0]], 1), g("torp_l", [[0.0, 0.30, 90, 60], [0.0, -0.30, -90, 60]], 2), g("ciws", [[-0.28, 0.0]], 3)],
		{"desc": "Stealth hull, rapid 76mm gun, homing torpedoes and CIWS."}))
	a.append(_s("eboat", "Schnellboot", 2, "Fast Torpedo Boat", "boat", 44.0, 7.5, 140.0, 200.0, 2.8, 600.0, 1.0, ["boost"], "",
		[g("ac20", [[0.30, 0.0]], 1), g("torp", [[0.08, 0.32, 90, 60], [0.08, -0.32, -90, 60]], 2), g("ac40", [[-0.30, 0.0]], 1)],
		{"desc": "Quad torpedo salvo at high speed."}))
	a.append(_s("gun_monitor", "Heavy Gunboat", 2, "Gunboat", "boat", 52.0, 9.0, 180.0, 150.0, 2.2, 620.0, 1.0, ["repair"], "",
		[g("g100", [[0.30, 0.0]], 1), g("g76", [[-0.28, 0.0]], 1), g("mg", [[0.0, 0.0]], 2)],
		{"desc": "Two dual-purpose guns on a sturdy hull."}))
	# ================= TIER III =================
	a.append(_s("river", "River-class Frigate", 3, "Escort Frigate", "ww2s", 70.0, 10.5, 270.0, 140.0, 1.9, 780.0, 1.0, ["repair", "smoke"], "",
		[g("g100", [[0.30, 0.0], [-0.30, 0.0]], 1), g("ac40", [[-0.12, 0.0], [-0.40, 0.0]], 2), g("rocket", [[0.12, 0.0, 0, 45]], 4), g("mine", [[-0.5, 0.0, 180, 10]], 8)],
		{"desc": "Two 100mm guns, a Hedgehog rocket launcher and depth charges."}))
	a.append(_s("type23", "Modern Frigate", 3, "Frigate", "modm", 84.0, 11.0, 320.0, 150.0, 2.0, 950.0, 1.0, ["chaff", "radar"], "uav",
		[g("g127m", [[0.30, 0.0]], 1), g("torp_l", [[-0.10, 0.30, 90, 60], [-0.10, -0.30, -90, 60]], 3), g("ac40", [[0.05, 0.0]], 2), g("rocket_h", [[0.08, 0.0, 0, 40]], 2), g("ciws", [[-0.18, 0.0]], 6)],
		{"desc": "Recon drone, 127mm gun, homing torpedoes and unguided missile salvos."}))
	a.append(_s("krivak", "Krivak-class Frigate", 3, "Soviet Frigate", "rum", 78.0, 11.0, 300.0, 155.0, 1.9, 880.0, 1.0, ["smoke", "boost"], "",
		[g("g76", [[0.30, 0.0], [-0.30, 0.0]], 2), g("rocket", [[0.16, 0.0, 0, 50]], 6), g("torp", [[-0.04, 0.30, 90, 60], [-0.04, -0.30, -90, 60]], 2)],
		{"desc": "Twin 76mm guns and anti-submarine rocket launchers."}))
	# ================= TIER IV =================
	a.append(_s("fletcher", "Fletcher-class Destroyer", 4, "Destroyer", "ww2m", 90.0, 10.8, 400.0, 140.0, 1.8, 900.0, 1.0, ["boost", "smoke"], "",
		[g("g127", [[0.34, 0.0], [0.23, 0.0], [-0.15, 0.0], [-0.27, 0.0], [-0.38, 0.0]], 1), g("ac40", [[0.0, 0.12], [-0.08, -0.12]], 2), g("torp", [[-0.04, 0.1, 90, 70], [-0.04, -0.1, -90, 70]], 5)],
		{"desc": "Five 127mm guns and two quintuple torpedo banks."}))
	a.append(_s("fubuki", "Fubuki-class Destroyer", 4, "Torpedo Destroyer", "jpm", 88.0, 9.8, 390.0, 150.0, 2.0, 900.0, 1.0, ["boost", "smoke"], "",
		[g("g127", [[0.30, 0.0], [-0.22, 0.0], [-0.34, 0.0]], 2), g("torp_h", [[0.06, 0.08, 90, 70], [0.06, -0.08, -90, 70]], 3), g("ac20", [[-0.05, 0.1], [-0.05, -0.1]], 2)],
		{"desc": "Devastating long-range oxygen torpedoes."}))
	a.append(_s("burke", "Arleigh Burke-class Destroyer", 4, "Guided-Missile Destroyer", "modm", 104.0, 13.0, 470.0, 155.0, 1.9, 1150.0, 1.0, ["radar", "repair"], "heli_asw",
		[g("g127m", [[0.30, 0.0]], 1), g("cruise", [[0.17, 0.0, 0, 0], [-0.10, 0.0, 0, 0]], 4), g("ssm_l", [[0.0, 0.3, 50, 15], [0.0, -0.3, -50, 15]], 4), g("torp_l", [[-0.2, 0.3, 90, 60], [-0.2, -0.3, -90, 60]], 3), g("ciws", [[0.06, 0.0], [-0.34, 0.0]], 6)],
		{"desc": "Cruise missiles guided by your cursor. Carries an ASW helicopter.", "cz": 0.95}))
	a.append(_s("sovremenny", "Sovremenny-class Destroyer", 4, "Missile Destroyer", "rum", 100.0, 12.0, 430.0, 150.0, 1.8, 1050.0, 1.0, ["smoke", "chaff"], "heli_scout",
		[g("g127", [[0.32, 0.0], [-0.32, 0.0]], 2), g("ssm_h", [[0.16, 0.30, 25, 10], [0.16, -0.30, -25, 10]], 2), g("ssm_s", [[0.05, 0.3, 30, 15], [0.05, -0.3, -30, 15]], 2), g("rocket", [[0.02, 0.0, 0, 40]], 6), g("ciws", [[-0.12, 0.2], [-0.12, -0.2]], 4)],
		{"desc": "Heavy supersonic and light missiles. Carries a scout helicopter."}))
	# ================= TIER V =================
	a.append(_s("cleveland", "Cleveland-class Light Cruiser", 5, "Light Cruiser", "ww2l", 124.0, 13.5, 650.0, 135.0, 1.5, 1050.0, 1.0, ["repair", "smoke"], "floatplane",
		[g("g152", [[0.34, 0.0], [0.23, 0.0], [-0.25, 0.0], [-0.36, 0.0]], 3), g("g127", [[0.10, 0.2], [0.10, -0.2], [-0.12, 0.2], [-0.12, -0.2]], 2), g("ac40", [[0.0, 0.24], [-0.04, -0.24]], 4)],
		{"desc": "Twelve 152mm guns in four triple turrets."}))
	a.append(_s("ticonderoga", "Ticonderoga-class Cruiser", 5, "Guided-Missile Cruiser", "modl", 134.0, 15.0, 800.0, 148.0, 1.6, 1300.0, 1.0, ["radar", "repair"], "heli_asw",
		[g("g127m", [[0.34, 0.0], [-0.32, 0.0]], 1), g("cruise", [[0.20, 0.0, 0, 0], [-0.20, 0.0, 0, 0]], 8), g("ssm_l", [[0.0, 0.3, 50, 15], [0.0, -0.3, -50, 15]], 4), g("torp_l", [[-0.08, 0.3, 90, 60], [-0.08, -0.3, -90, 60]], 3), g("ciws", [[0.08, 0.0], [-0.40, 0.0]], 6)],
		{"desc": "Sixteen cruise missiles and an ASW helicopter.", "cz": 0.95}))
	a.append(_s("agano", "Agano-class Light Cruiser", 5, "Light Cruiser", "jpl", 120.0, 12.5, 630.0, 148.0, 1.7, 1000.0, 1.0, ["boost", "smoke"], "floatplane",
		[g("g152", [[0.34, 0.0], [0.22, 0.0], [-0.32, 0.0]], 2), g("g100", [[0.04, 0.2], [-0.10, -0.2]], 2), g("torp_h", [[-0.20, 0.12, 90, 70], [-0.20, -0.12, -90, 70]], 4)],
		{"desc": "Fast cruiser with long-range torpedoes."}))
	# ================= TIER VI =================
	a.append(_s("baltimore", "Baltimore-class Heavy Cruiser", 6, "Heavy Cruiser", "ww2l", 150.0, 16.0, 900.0, 130.0, 1.3, 1150.0, 1.0, ["repair", "smoke"], "floatplane",
		[g("g203", [[0.34, 0.0], [0.23, 0.0], [-0.30, 0.0]], 3), g("g127", [[0.08, 0.2], [0.08, -0.2], [-0.10, 0.2], [-0.10, -0.2]], 2), g("ac40", [[0.0, 0.25], [-0.2, -0.25]], 4)],
		{"desc": "Nine 203mm guns. A balanced cruiser."}))
	a.append(_s("takao", "Takao-class Heavy Cruiser", 6, "Heavy Cruiser", "jpl", 152.0, 15.5, 880.0, 142.0, 1.4, 1100.0, 1.0, ["boost", "smoke"], "floatplane",
		[g("g203", [[0.35, 0.0], [0.26, 0.0], [0.17, 0.0], [-0.30, 0.0], [-0.40, 0.0]], 2), g("g127", [[0.0, 0.2], [0.0, -0.2]], 2), g("torp_h", [[-0.12, 0.12, 90, 70], [-0.12, -0.12, -90, 70]], 4)],
		{"desc": "Ten 203mm guns and quad long-lance torpedoes."}))
	a.append(_s("slava", "Slava-class Missile Cruiser", 6, "Missile Cruiser", "rul", 168.0, 19.0, 980.0, 138.0, 1.3, 1400.0, 1.0, ["radar", "chaff"], "heli_attack",
		[g("ssm_h", [[0.26, 0.30, 35, 15], [0.26, -0.30, -35, 15], [0.12, 0.30, 35, 15], [0.12, -0.30, -35, 15]], 2), g("g127", [[0.38, 0.0]], 2), g("rocket_h", [[0.30, 0.0, 0, 45]], 4), g("torp_w", [[-0.05, 0.28, 90, 60], [-0.05, -0.28, -90, 60]], 2), g("ciws", [[-0.10, 0.22], [-0.10, -0.22], [-0.30, 0.0]], 6)],
		{"desc": "Eight heavy missiles. Carries an attack helicopter.", "cz": 0.92}))
	# ================= TIER VII =================
	a.append(_s("scharnhorst", "Scharnhorst-class Battlecruiser", 7, "Battlecruiser", "ww2l", 180.0, 20.0, 1300.0, 150.0, 1.2, 1250.0, 1.0, ["repair", "barrage"], "floatplane",
		[g("g305", [[0.34, 0.0], [0.22, 0.0], [-0.30, 0.0]], 3), g("g152", [[0.04, 0.22], [0.04, -0.22], [-0.14, 0.22], [-0.14, -0.22]], 2), g("ac40", [[0.14, 0.26], [-0.04, -0.26]], 4)],
		{"desc": "Nine 305mm guns and fast for her size."}))
	a.append(_s("kongo", "Kongo-class Battlecruiser", 7, "Battlecruiser", "jpl", 178.0, 20.0, 1250.0, 160.0, 1.3, 1200.0, 1.0, ["boost", "barrage"], "floatplane",
		[g("g356", [[0.35, 0.0], [0.24, 0.0], [-0.24, 0.0], [-0.35, 0.0]], 2), g("g152", [[0.08, 0.22], [0.0, 0.22], [-0.08, 0.22], [0.08, -0.22], [0.0, -0.22], [-0.08, -0.22]], 1), g("ac40", [[0.14, 0.0], [-0.14, 0.0]], 4)],
		{"desc": "Eight 356mm guns in four twin turrets."}))
	a.append(_s("kirov", "Kirov-class Battlecruiser", 7, "Nuclear Missile Cruiser", "rul", 196.0, 24.0, 1400.0, 145.0, 1.1, 1550.0, 1.0, ["radar", "repair"], "heli_attack",
		[g("ssm_h", [[0.30, 0.14, 20, 15], [0.30, -0.14, -20, 15]], 8), g("ssm_l", [[0.12, 0.3, 40, 15], [0.12, -0.3, -40, 15]], 4), g("g127", [[0.42, 0.0]], 2), g("rocket", [[0.24, 0.0, 0, 40]], 8), g("ciws", [[0.05, 0.28], [0.05, -0.28], [-0.20, 0.28], [-0.20, -0.28]], 6)],
		{"desc": "Sixteen heavy missiles, rocket launchers and CIWS.", "cz": 0.9}))
	# ================= TIER VIII =================
	a.append(_s("iowa", "Iowa-class Battleship", 8, "Battleship", "ww2l", 208.0, 24.0, 1700.0, 140.0, 1.0, 1350.0, 1.0, ["repair", "barrage"], "floatplane",
		[g("g406", [[0.34, 0.0], [0.22, 0.0], [-0.28, 0.0]], 3), g("g127", [[0.10, 0.22], [0.10, -0.22], [-0.02, 0.22], [-0.02, -0.22], [-0.14, 0.22], [-0.14, -0.22]], 2), g("ac40", [[0.0, 0.0], [-0.20, 0.0]], 4)],
		{"desc": "Nine 406mm guns. The classic battleship."}))
	a.append(_s("yamato", "Yamato-class Battleship", 8, "Super Battleship", "jpl", 220.0, 25.0, 1950.0, 130.0, 0.95, 1400.0, 1.0, ["repair", "barrage"], "floatplane",
		[g("g460", [[0.34, 0.0], [0.22, 0.0], [-0.28, 0.0]], 3), g("g152", [[0.08, 0.0], [-0.14, 0.0]], 3), g("g127", [[0.0, 0.23], [0.0, -0.23], [-0.06, 0.23], [-0.06, -0.23]], 2), g("ac40", [[0.14, 0.0]], 4)],
		{"desc": "Nine 460mm guns. Slow, enormous, devastating."}))
	a.append(_s("bismarck", "Bismarck-class Battleship", 8, "Battleship", "ww2l", 200.0, 24.0, 1600.0, 150.0, 1.05, 1300.0, 1.0, ["smoke", "barrage"], "floatplane",
		[g("g381", [[0.33, 0.0], [0.22, 0.0], [-0.24, 0.0], [-0.34, 0.0]], 2), g("g152", [[0.06, 0.22], [0.06, -0.22], [-0.04, 0.22], [-0.04, -0.22], [-0.14, 0.22], [-0.14, -0.22]], 2), g("ac40", [[0.14, 0.0], [-0.18, 0.0]], 4)],
		{"desc": "Eight 381mm guns. Faster and nimbler than her rivals."}))
	a.append(_s("carrier", "Fleet Carrier", 8, "Aircraft Carrier", "cv", 240.0, 32.0, 1500.0, 135.0, 0.85, 1500.0, 1.0, ["radar", "repair"], "carrier_bomber",
		[g("g127", [[0.40, 0.3], [0.30, -0.36], [-0.30, 0.36], [-0.40, -0.3]], 1), g("ac40", [[0.2, 0.38], [0.0, -0.38], [-0.2, 0.38]], 2), g("ciws", [[0.34, -0.3], [-0.46, 0.0]], 6)],
		{"desc": "Weak guns - fly your bombers (V) to fight.", "cz": 0.85}))
	a.append(_s("arsenal", "Arsenal Ship", 8, "Missile Battleship", "ars", 200.0, 24.0, 1600.0, 150.0, 1.1, 1700.0, 1.0, ["radar", "chaff"], "heli_attack",
		[g("cruise", [[0.30, 0.0, 0, 0], [0.12, 0.0, 0, 0], [-0.10, 0.0, 0, 0], [-0.40, 0.0, 0, 0]], 4), g("ssm_h", [[0.20, 0.3, 30, 15], [0.20, -0.3, -30, 15]], 6), g("ssm_s", [[0.0, 0.3, 30, 15], [0.0, -0.3, -30, 15]], 4), g("g155", [[0.42, 0.0], [-0.30, 0.0]], 2), g("ciws", [[0.05, 0.28], [-0.2, -0.28]], 6)],
		{"desc": "Sixteen cursor-guided cruise missiles and heavy missiles.", "cz": 0.85}))
	return a

# firepower estimate (sustained damage per second if everything hits) - used by the ship cards
static func dps(def: Dictionary) -> float:
	var tot := 0.0
	var rlm := float(def["rlm"])
	for gr in def["weapons"]:
		var wd: Dictionary = WEAPONS[gr["w"]]
		var barrels := 0
		for m in gr["m"]:
			barrels += int(m["b"])
		var per := float(wd["dmg"]) * float(wd.get("sal", 1))
		var by_reload := per * float(barrels) / maxf(float(wd["rl"]) * rlm, 0.05)
		var by_gap := per / maxf(float(wd["gap"]) * rlm, 0.02)
		tot += minf(by_reload, by_gap)
	return tot

static func mount_dims(wd: Dictionary, b: int) -> Vector2:
	# returns Vector2(muzzle forward offset, barrel spacing)
	match str(wd["vis"]):
		"gun":
			var bw := float(wd["bw"])
			var bl := float(wd["bl"])
			var tl := bl * 0.6 + 4.0
			return Vector2(tl * 0.3 + bl, bw * 1.4)
		"ciws":
			return Vector2(6.0, 1.0)
		"tubes":
			return Vector2(float(wd.get("tl", 10.0)) * 0.5 + 2.0, 2.6)
		"can":
			return Vector2(7.0, 3.2)
		"vls":
			return Vector2(0.0, 0.0)
		"rack":
			return Vector2(7.0, 2.4)
		"mine":
			return Vector2(2.0, 3.0)
	return Vector2(6.0, 2.0)

# Hull outline, stern at -L/2 and bow at +L/2.  bow = where the taper starts (0..1),
# bp = bow fullness, st = transom width (0..1).
static func hull_pts(L: float, W: float, bow: float, bp: float, st: float) -> PackedVector2Array:
	var n := 26
	var top := PackedVector2Array()
	var bot := PackedVector2Array()
	for i in range(n + 1):
		var u := float(i) / float(n)
		var f := 1.0
		if u < 0.12:
			f = st + (1.0 - st) * sin(u / 0.12 * PI * 0.5)
		elif u > bow:
			var t := (u - bow) / (1.0 - bow)
			f = pow(maxf(1.0 - pow(t, bp), 0.0), 0.55)
		var x := -L * 0.5 + u * L
		var hw := W * 0.5 * f
		top.append(Vector2(x, -hw))
		if i < n:
			bot.append(Vector2(x, hw))
	var pts := PackedVector2Array()
	for p in top:
		pts.append(p)
	var j := bot.size() - 1
	while j >= 0:
		pts.append(bot[j])
		j -= 1
	return pts

static func half_width(x: float, L: float, W: float, bow: float, bp: float, st: float) -> float:
	var u := clampf((x + L * 0.5) / L, 0.0, 1.0)
	var f := 1.0
	if u < 0.12:
		f = st + (1.0 - st) * sin(u / 0.12 * PI * 0.5)
	elif u > bow:
		var t := (u - bow) / (1.0 - bow)
		f = pow(maxf(1.0 - pow(t, bp), 0.0), 0.55)
	return W * 0.5 * f
