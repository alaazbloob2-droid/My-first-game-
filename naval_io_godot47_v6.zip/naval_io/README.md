# Naval IO (Godot 4.x, Compatibility renderer)

Open `project.godot` in Godot 4 and press F5.

## Files
| file | purpose |
|---|---|
| `data.gd` | **All content**: tiers, 28 ships, weapons, aircraft, abilities. Add ships/weapons here. |
| `main.gd` | World, ship renderer, weapon mounts, projectiles, fire/flood, detection, AI, aircraft, effects |
| `ui.gd` | HUD, menu, promotion / respawn pop-ups, settings window |
| `audio.gd` | Procedural sound synthesis (no audio files needed) |
| `settings.gd` | All options + key bindings, saved to `user://naval_io_settings.cfg` |
| `water.gdshader` | Ocean shader (3 quality levels) |

## Controls (rebindable in Settings -> Controls)
* W/S throttle, A/D steer, mouse aims
* LMB / RMB / Space fire the **selected** weapon; click the weapon bar or press 1-9 to select
* Q / E abilities, V aircraft (your ship then sails on AUTOPILOT), U promotion window
* Wheel zoom, Esc settings, F2 graphics quality, F3 FPS

## Weapons by tier
* Tier I-II: guns, torpedoes and mines only - no missiles or rockets.
* Tier III: unguided rockets / unguided missile salvos.
* Tier IV+: guided missiles in four families - light, sea-skimmer, heavy supersonic and long-range
  cruise - each with its own silhouette and colours.

## Performance design (weak GPUs such as Intel HD 4000)
* **Baking**: every ship hull, gun turret, island, reef and wreck is rendered ONCE into a texture at start-up
  (4x MSAA + mipmaps) and shown as a sprite. Same picture, but a handful of draw calls instead of hundreds.
  Start-up shows "Preparing the world..." for a few seconds while this happens.
* **Water shader** reads a pre-computed wave texture instead of evaluating ~25 trig functions per pixel.
* **CPU**: spatial grids for islands, reefs, crates and ship-vs-shot checks; AI ships only rotate the turrets of
  the weapon they use; distant idle ships are simulated every 4th frame; empty effect layers are not redrawn.
* Ships are hidden with `modulate`, never `visible` (toggling visibility forces Godot to redraw all children).
* Auto quality removes MSAA first, then lowers detail, only when FPS stays below 36. F3 shows FPS and draw calls.

## Diagnosing performance (F4)
Press **F4** for the profiler: FPS, script time per section (ships / shots / visuals / HUD), draw calls,
objects, primitives, node count, texture memory, and which auto-graphics steps are active.
**F5-F9** switch whole parts off (water, islands, ships, effects, HUD) so you can see which one costs the frames.
Auto graphics only acts while you are playing, tries one step at a time (anti-aliasing, then fast water, then
detail) and automatically undoes any step that does not give at least 12% more FPS.

## Tactical rules
* **Fog of war**: you only see ships inside your detection range (x their stealth; small ships are
  harder to spot). Firing reveals you, smoke hides you, radar / aircraft / marking extend vision.
* **Firing**: a weapon fires from the mount CLOSEST to your cursor; barrels in that turret fire in order.
* **Missiles and homing torpedoes** lock the visible enemy closest to the direction you aimed in when
  they launch (they do not follow the cursor). Missiles start at Tier IV and reach 1500-4200 px.
* **Anti-aircraft is manual**: select an AA weapon (tagged AA) and shoot aircraft or incoming missiles.
  AI ships with CIWS defend automatically. While you fly an aircraft your ship's CIWS also defends.
* **Fire (5% per heavy hit) and flooding (2%)**: burn / flood damage over time; flooding slows the ship.
  Damage Control puts both out.
* **Enemy aircraft**: carriers send bombers, helicopters attack, scouts mark you for focus fire.
* AI fires one weapon at a time, switches deliberately, keeps its range and retreats when out-tiered.
